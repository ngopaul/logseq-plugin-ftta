- ### Blend us, Lord, Blend us, Lord
  id:: a0b00008-a000-b000-b1b1-b1b1b1b1b1b1
-
- 1
    - Blend us, Lord, blend us, Lord, ’til we are in one accord.
    Hallelujah—the saints going on!
    Blend us, Lord, blend us, Lord, open hearts we can afford.
    Hallelujah—the churches go on!
    As the members of
    His organic Body,
    We need the others to go on.
    As local churches,
    We do also need
    One another for our going on.
    id:: a0b00008-a001-b1b1-b1b1-b1b1b1b1b1b1
- 2
    - Build us up, build us up, as with one another sup’.
    Hallelujah—the riches of Christ!
    Build us up, build us up, as with You we all rise up.
    Hallelujah—the living Body!
    As blended members
    Of His one Body,
    We, the Lord do glorify!
    His Light does shine!
    Reviving Life does flow!
    And we do see that Satan is crushed!
    id:: a0b00008-a002-b1b1-b1b1-b1b1b1b1b1b1
- 3
    - Bless us, Lord! bless us, Lord! All prevailing is Your blood!
    Hallelujah, we’re built up in love!
    Consummate! Consummate! All Your purpose consummate!
    Hallelujah—“The fullness thereof!”
    The gates of Hades
    Never will prevail
    Against the builded up church!
    When we are one,
    The enemy is done!
    The Lord Jesus is able to come!
    id:: a0b00008-a003-b1b1-b1b1-b1b1b1b1b1b1
- 4
    - Intercede! Intercede! For Your people, meet Your need! 
    Hallelujah! Get Your Bride this way. 
    Have Your way! Have Your way! Do a building work we pray—
    Hallelujah—in our life each day! 
    Through the cross of Jesus, 
    By the Spirit filled, 
    We are blending, building up! 
    We all are one! 
    We are...Jerusalem! 
    Dear Lord Jesus, we ask You to come!
    id:: a0b00008-a004-b1b1-b1b1-b1b1b1b1b1b1
